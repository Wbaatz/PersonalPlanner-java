package application;

import java.awt.Toolkit;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.effect.Shadow;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;

public class Login {

	@FXML
	private AnchorPane main_anc;
	@FXML
	Button login;
	@FXML
	TextField username;
	@FXML
	PasswordField password;
	@FXML
	Label wronglogin;
	@FXML
	Button signup;
	@FXML
	Button forgot_Pass;
	
	private Parent root;
	java.sql.PreparedStatement pst;
	@FXML
	private void keyPressed(KeyEvent keyEvent) throws IOException, SQLException {
    if (keyEvent.getCode() == KeyCode.ENTER) {
         
		check_login();
    }
	}
	public void login(ActionEvent e) throws IOException, SQLException{
		
		check_login();
	}
	
    public void signup(ActionEvent e) throws IOException{
		
		user_signup();
	}
	
	public void user_signup() throws IOException{
		
		Main m = new Main();
		m.changescene("SignUp.fxml");
	}
	
    public void Forgot(ActionEvent e) throws IOException {
		
		Main m = new Main();
		m.changescene("ForgetPassword.fxml");
	}
    
    public void check_login() throws IOException, SQLException{
    	
    	Main m = new Main();
    	String name = username.getText().toString();
		String pass = password.getText().toString();
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/users","root","");
		PreparedStatement pst = (PreparedStatement) con.prepareStatement("select * from users_accounts where Username=? and Password=?");
		pst.setString(1,name);
		pst.setString(2,pass);
		ResultSet r = pst.executeQuery();
		if(r.next()) {
			
			m.changescene("Planner.fxml");
		}else if(username.getText().isEmpty() && password.getText().isEmpty()){
				
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter Username and Password");
				errorAlert.showAndWait();
				wronglogin.setText("Enter Your Data");
			}else {
				
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("Wrong Input");
				errorAlert.setContentText("Please Enter Correct Username and Password");
				errorAlert.showAndWait();
				wronglogin.setText("wrong username or password");
			}
    }
}
