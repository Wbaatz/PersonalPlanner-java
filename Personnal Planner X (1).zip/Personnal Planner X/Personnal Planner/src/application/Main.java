package application;
	
import java.io.File;
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;

public class Main extends Application {
	private static Stage stg;
	public static void main(String[] args) {
		
		launch(args);
	}

	@Override
	public void start(Stage stage) { 
		
		try{
			
		stg = stage;
		Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setTitle("Personnal Planner");
		//String path = "logo.png";
		//File fileIcon = new File(path);
		//Image Icon = new Image(fileIcon.toURI().toString());
		//stage.getIcons().add(Icon);
		stage.setWidth(1270);
		stage.setHeight(820);
		stage.setResizable(false);
		scene.setFill(Color.TRANSPARENT);
		stage.setScene(scene);
		
		stage.show();
		}catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public void changescene(String fxml) throws IOException{
		Parent pane = FXMLLoader.load(getClass().getResource(fxml));
		stg.getScene().setRoot(pane);
	}
}
