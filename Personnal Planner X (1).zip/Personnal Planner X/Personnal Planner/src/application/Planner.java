package application;


import java.awt.Toolkit;
import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.BubbleChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.PieChart.Data;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Border;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane ;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class Planner {

	////////////////////////////////////////////   Log In   ////////////////////////////////////////////////////
	@FXML
	Label user;
	@FXML
	Label email;
	@FXML
	private Button Logout;
   
    public void display_user(String name) {
    	
    	System.out.println(name);
    	user.setText(name);
    	
    }
    public void Logout(ActionEvent e) throws IOException {
		
    	Main m = new Main();
		m.changescene("Main.fxml");
	}
	public void Back(ActionEvent e) {
		
		EventPlanner.setStyle("visibility: false");
		BudgetPlanner.setStyle("visibility: false");
		Main.setStyle("visibility: true");
		
	}
	@FXML
	AnchorPane AboutUs;
	@FXML
	AnchorPane AboutProject;
	@FXML
	AnchorPane C;
	
	public void AboutUS(ActionEvent e) {
		
		Alert Alert = new Alert(AlertType.INFORMATION);
		Alert.setTitle("About Us");
		Alert.setHeaderText(" ");
		Alert.setGraphic(AboutUs);
		AboutUs.setStyle("visibility: true");
		Alert.showAndWait();
	}
   public void AboutP(ActionEvent e) {
		
		Alert Alert = new Alert(AlertType.INFORMATION);
		Alert.setTitle("About Project");
		Alert.setHeaderText(" ");
		Alert.setGraphic(AboutProject);
		AboutProject.setStyle("visibility: true");
		Alert.showAndWait();
	}
   public void Contact(ActionEvent e) {
	
	Alert Alert = new Alert(AlertType.INFORMATION);
	Alert.setTitle("Contact");
	Alert.setHeaderText(" ");
	Alert.setGraphic(C);
	C.setStyle("visibility: true");
	Alert.showAndWait();
}
    ///////////////////////////////////////////   Routine   ///////////////////////////////////////////////////
    
   
    ///////  Color: #3ac78b //////////////////
	//////   Color:  #b92323 /////////////////
    @FXML
    AnchorPane Main;
    @FXML
    AnchorPane timer;
    @FXML
    AnchorPane routines;
    @FXML
    AnchorPane BudgetPlanner;
    @FXML
    AnchorPane EventPlanner;
    @FXML
    AnchorPane EventTracker;
    @FXML
    AnchorPane InfoTracker;
    @FXML
    Button back;
    @FXML
    Button plus;
    @FXML
    AnchorPane routine1;
    @FXML
    AnchorPane routine2;
    @FXML
    AnchorPane routine3;
    @FXML
    AnchorPane routine4;
    @FXML
    AnchorPane routine5;
    @FXML
    AnchorPane routine6;
    @FXML
    AnchorPane routine7;
    @FXML
    AnchorPane routine8;
    @FXML
    AnchorPane setter1;
    @FXML
    AnchorPane setter2;
    @FXML
    AnchorPane setter;
    @FXML
    Label rt1;
    @FXML
    Label rt2;
    @FXML
    Label rt3;
    @FXML
    Label rt4;
    @FXML
    Label rt5;
    @FXML
    Label rt6;
    @FXML
    Label rt7;
    @FXML
    Label rt8;
    @FXML
    Label time1;
    @FXML
    Label time2;
    @FXML
    Label time3;
    @FXML
    Label time4;
    @FXML
    Label time5;
    @FXML
    Label time6;
    @FXML
    Label time7;
    @FXML
    Label time8;
    @FXML
    Button set1;
    @FXML
    Button add1;
    @FXML
    TextField rot1;
    @FXML
    TextField hr1;
    @FXML
    TextField hr2;
    @FXML
    TextField min2;
    @FXML
    TextField min1;
    @FXML
    Label wrong;
    
    @FXML
    Button done1;
    @FXML
    Button miss1;
    @FXML
    Button done2;
    @FXML
    Button miss2;
    @FXML
    Button done3;
    @FXML
    Button miss3;
    @FXML
    Button done4;
    @FXML
    Button miss4;
    @FXML
    Button done5;
    @FXML
    Button miss5;
    @FXML
    Button done6;
    @FXML
    Button miss6;
    @FXML
    Button done7;
    @FXML
    Button miss7;
    @FXML
    Button done8;
    @FXML
    Button miss8;
    
    public void Budget_Planner(ActionEvent e) {
    	
    	Main.setStyle("visibility: false");
    	BudgetPlanner.setStyle("visibility: true");
    }
    
    public void Event_Planner(ActionEvent e) {
    	
    	Main.setStyle("visibility: false");
    	evTotalExpense.setText("        $"+Integer.toString(total_expenses));
		evTotalEarning.setText("        $"+Integer.toString(total_earnings));
		evTotalSaving.setText("         $"+Integer.toString(total_savings));
    	EventPlanner.setStyle("visibility: true");
    }
    
    public void Event_Tracker(ActionEvent e) {
    	Main.setStyle("visibility: false");
    	myGrid.setVisible(true);
    	EventTracker.setStyle("visibility: true");
    }
    
    //////////////   Routine Division   ////////////////////
    @FXML
    AnchorPane percent;
    @FXML
    AnchorPane modes;
    @FXML
    Button prgmode;
    @FXML
    Button dstmode;
    @FXML
    Button aboutus;
    @FXML
    Button aboutprj;
    @FXML
    Button Contact;
    @FXML
    Button logout;
    @FXML
    PieChart PC1;
    @FXML
    Label lb1;
    @FXML
    Label lbt1;
    @FXML
    Label lb2;
    @FXML
    Label lbt2;
    @FXML
    Label lb3;
    @FXML
    Label lbt3;
    @FXML
    Label lb4;
    @FXML
    Label lbt4;
    @FXML
    Label lb5;
    @FXML
    Label lbt5;
    @FXML
    Label lb6;
    @FXML
    Label lbt6;
    @FXML
    Label lb7;
    @FXML
    Label lbt7;
    @FXML
    Label lb8;
    @FXML
    Label lbt8; 
    static int t=0;
    int times[] = new int[8];
    String routiner[] = new String[8];
  //  static ObservableList<PieChart.Data> PieData=FXCollections.observableArrayList();
     
     public void Progress_Mode(ActionEvent e) {
    	 
    	 timer.setStyle("visibility: false");
    	 modes.setStyle("visibility: true");
     }
    public void Distribution_Mode(ActionEvent e) {
    	
    	EventPlanner.setStyle("visibility: false");
		BudgetPlanner.setStyle("visibility: false");
		Main.setStyle("visibility: true");
    	 timer.setStyle("visibility: true");
    	 modes.setStyle("visibility: false");
    	 ObservableList<PieChart.Data> pieChartData = null;
    		 
    		 pieChartData = FXCollections.observableArrayList(  new PieChart.Data(routiner[0],times[0]),
    				                                            new PieChart.Data(routiner[1],times[1]),
    				                                            new PieChart.Data(routiner[2],times[2]),
    				                                            new PieChart.Data(routiner[3],times[3]),
    				                                            new PieChart.Data(routiner[4],times[4]),
    				                                            new PieChart.Data(routiner[5],times[5]),
    				                                            new PieChart.Data(routiner[6],times[6]),
    				                                            new PieChart.Data(routiner[7],times[7]));
    	 PC1.setData(pieChartData);
    	 
    	 lb1.setText(routiner[0]);
    	 lb2.setText(routiner[1]);
    	 lb3.setText(routiner[2]);
    	 lb4.setText(routiner[3]);
    	 lb5.setText(routiner[4]);
    	 lb6.setText(routiner[5]);
    	 lb7.setText(routiner[6]);
    	 lb8.setText(routiner[7]);
    	 lbt1.setText(Integer.toString(times[0])+"%");
    	 lbt2.setText(Integer.toString(times[1])+"%");
    	 lbt3.setText(Integer.toString(times[2])+"%");
    	 lbt4.setText(Integer.toString(times[3])+"%");
    	 lbt5.setText(Integer.toString(times[4])+"%");
    	 lbt6.setText(Integer.toString(times[5])+"%");
    	 lbt7.setText(Integer.toString(times[6])+"%");
    	 lbt8.setText(Integer.toString(times[7])+"%");
    	 
    	 
     }
     
    /////////////   Main Page   ///////////////////
    @FXML
    Button Budgetplan;
    @FXML
    Button Eventplan;
    @FXML
    Button Eventtracker;
    @FXML
    Button Info;
    @FXML
 	private NumberAxis nx;
 	@FXML
 	private CategoryAxis cs;
 	@FXML
 	private BarChart<String,Number> time;
 	static XYChart.Series<String,Number> series = new XYChart.Series<>();
    
    public int bari;
    public int bhejo = 1;
    
    public void plusRoutine(ActionEvent e) {
    	
    	if(bhejo==1) {
    		
    		addR1(e);
    		bhejo++;
    	}else if(bhejo==2) {
    		
    		addR2(e);
    		bhejo++;
    	}else if(bhejo==3) {
    		
    		addR3(e);
    		bhejo++;
    	}else if(bhejo==4) {
    		
    		addR4(e);
    		bhejo++;
    	}else if(bhejo==5) {
    		
    		addR5(e);
    		bhejo++;
    	}else if(bhejo==6) {
    		
    		addR6(e);
    		bhejo++;
    	}else if(bhejo==7) {
    		
    		addR7(e);
    		bhejo++;
    	}else if(bhejo==8) {
    		
    		addR8(e);
    		bhejo++;
    		plus.setStyle("visibility:false");
    	}
    }
    public void addR1(ActionEvent e) {
    	
    	bari = 1;
    	wrong.setText("");
    	rot1.setText("");
       	hr1.setText("");
       	hr2.setText("");
       	min1.setText("");
       	min2.setText("");
    	setter2.setStyle("visibility:false");
    	setter1.setStyle("visibility: true");
    	Alert Alert = new Alert(AlertType.INFORMATION);
		Alert.setTitle("Set Routine");
		Alert.setHeaderText(" ");
		Alert.setGraphic(setter);
		Alert.showAndWait();
    }
    public void addR2(ActionEvent e) {
    	
    	bari = 2;
    	wrong.setText("");
    	rot1.setText("");
       	hr1.setText("");
       	hr2.setText("");
       	min1.setText("");
       	min2.setText("");
    	setter2.setStyle("visibility:false");
    	setter1.setStyle("visibility: true");
    	Alert Alert = new Alert(AlertType.INFORMATION);
		Alert.setTitle("Set Routine");
		Alert.setHeaderText(" ");
		Alert.setGraphic(setter);
		Alert.showAndWait();
    }
    public void addR3(ActionEvent e) {
	
    	bari = 3;
    	wrong.setText("");
    	rot1.setText("");
       	hr1.setText("");
       	hr2.setText("");
       	min1.setText("");
       	min2.setText("");
    	setter2.setStyle("visibility:false");
	setter1.setStyle("visibility: true");
	Alert Alert = new Alert(AlertType.INFORMATION);
	Alert.setTitle("Set Routine");
	Alert.setHeaderText(" ");
	Alert.setGraphic(setter);
	Alert.showAndWait();
}
   public void addR4(ActionEvent e) {
 	
	   bari = 4;
	   wrong.setText("");
	   rot1.setText("");
	   	hr1.setText("");
	   	hr2.setText("");
	   	min1.setText("");
	   	min2.setText("");
   	setter2.setStyle("visibility:false");
	setter1.setStyle("visibility: true");
	Alert Alert = new Alert(AlertType.INFORMATION);
	Alert.setTitle("Set Routine");
	Alert.setHeaderText(" ");
	Alert.setGraphic(setter);
	Alert.showAndWait();
}
   public void addR5(ActionEvent e) {
	
	   bari = 5;
	   wrong.setText("");
	   rot1.setText("");
	   	hr1.setText("");
	   	hr2.setText("");
	   	min1.setText("");
	   	min2.setText("");
   	setter2.setStyle("visibility:false");
	setter1.setStyle("visibility: true");
	Alert Alert = new Alert(AlertType.INFORMATION);
	Alert.setTitle("Set Routine");
	Alert.setHeaderText(" ");
	Alert.setGraphic(setter);
	Alert.showAndWait();
}
   public void addR6(ActionEvent e) {
	
	   bari = 6;
	   wrong.setText("");
	   rot1.setText("");
	   	hr1.setText("");
	   	hr2.setText("");
	   	min1.setText("");
	   	min2.setText("");
   	setter2.setStyle("visibility:false");
	setter1.setStyle("visibility: true");
	Alert Alert = new Alert(AlertType.INFORMATION);
	Alert.setTitle("Set Routine");
	Alert.setHeaderText(" ");
	Alert.setGraphic(setter);
	Alert.showAndWait();
}
   public void addR7(ActionEvent e) {
	
	   bari = 7;
	   wrong.setText("");
	   rot1.setText("");
	   	hr1.setText("");
	   	hr2.setText("");
	   	min1.setText("");
	   	min2.setText("");
   	setter2.setStyle("visibility:false");
	setter1.setStyle("visibility: true");
	Alert Alert = new Alert(AlertType.INFORMATION);
	Alert.setTitle("Set Routine");
	Alert.setHeaderText(" ");
	Alert.setGraphic(setter);
	Alert.showAndWait();
}
   public void addR8(ActionEvent e) {
	
	   bari = 8;
	   wrong.setText("");
	   rot1.setText("");
   	hr1.setText("");
   	hr2.setText("");
   	min1.setText("");
   	min2.setText("");
   	setter2.setStyle("visibility:false");
	setter1.setStyle("visibility: true");
	Alert Alert = new Alert(AlertType.INFORMATION);
	Alert.setTitle("Set Routine");
	Alert.setHeaderText(" ");
	Alert.setGraphic(setter);
	Alert.showAndWait();
}
  
    public void setrt1(ActionEvent e) {
    	
    	if(rot1.getText().isEmpty() || hr1.getText().isEmpty() || min1.getText().isEmpty() || hr2.getText().isEmpty() || min2.getText().isEmpty()) {
    		
    		wrong.setText("Please Enter Routine and Time");
    	}else {
    		
    		String routine = rot1.getText().toString();
        	String hour1 = hr1.getText().toString();
        	String m1 = min1.getText().toString();
        	String timea = hour1 + " : " + m1;
        	String hour2 = hr2.getText().toString();
        	String m2 = min2.getText().toString();
        	String timeb = hour2 + " : " + m2;
        	String Time = timea + " - " + timeb;
        	
        	int h1 = Integer.parseInt(hour1);
        	int h2 = Integer.parseInt(hour2);
        	int mn1 = Integer.parseInt(m1);
        	int mn2 = Integer.parseInt(m2);
        	int mins = Math.abs(mn2-mn1);
        	double hrs = h2-h1;
        	double minutes = ((double)mins/60)*100;
        	hrs += (minutes/100);
        	double percent = (hrs/24)*100;
        	String timer = routine;
            series = new XYChart.Series<>();
			series.setName(routine);
			Math.round(hrs);
			int prn = (int)percent;
        	System.out.println(percent);
        	if(h1>24 || h1<1 || h2>24 || h2<h1 || mn1<0 || mn1>60 || mn2<0 || mn2>60 || (h1==h2&&mn2<=mn1)) {
        		
        		wrong.setText("Invalid Time Input");
        	}else {
        		
        				if(bari==1) {
                			
                			rt1.setText(routine);
                        	time1.setText(Time);
                            times[0] = prn;
                            routiner[0] = routine;
                        	routine1.setStyle("visibility: true");
                		}else if(bari==2) {
                			
                			rt2.setText(routine);
                        	time2.setText(Time);
                        	times[1] = prn;
                        	routiner[1] = routine;
                        	routine2.setStyle("visibility: true");
                		}else if(bari==3) {
                			
                			rt3.setText(routine);
                        	time3.setText(Time);
                        	times[2] = prn;
                        	routiner[2] = routine;
                        	routine3.setStyle("visibility: true");
                		}else if(bari==4) {
                			
                			rt4.setText(routine);
                        	time4.setText(Time);
                        	times[3] = prn;
                        	routiner[3] = routine;
                        	routine4.setStyle("visibility: true");
                		}else if(bari==5) {
                			
                			rt5.setText(routine);
                        	time5.setText(Time);
                        	times[4] = prn;
                        	routiner[4] = routine;
                        	routine5.setStyle("visibility: true");
                		}else if(bari==6) {
                			
                			rt6.setText(routine);
                        	time6.setText(Time);
                        	times[5] = prn;
                        	routiner[5] = routine;
                        	routine6.setStyle("visibility: true");
                		}else if(bari==7) {
                			
                			rt7.setText(routine);
                        	time7.setText(Time);
                        	times[6] = prn;
                        	routiner[6] = routine;
                        	routine7.setStyle("visibility: true");
                		}else if(bari==8) {
                			
                			rt8.setText(routine);
                        	time8.setText(Time);
                        	times[7] = prn;
                        	routiner[7] = routine;
                        	routine8.setStyle("visibility: true");
                		}
                		
                    	setter1.setStyle("visibility: false");
                    	setter2.setStyle("visibility: true");
                    	//time.getData().addAll(series);
                    	
        			}
        		}
        		
        		
        	} 
    
///////////////////////////////////   Budget Planner   /////////////////////////////////////////////

@FXML
Button food;
@FXML
Button cloth;
@FXML
Button travel;
@FXML
Button education;
@FXML
Button utilities;
@FXML
Button exp1;
@FXML
Button exp2;
@FXML
Button exp3;
@FXML
Button exp4;
@FXML
Button exp5;
@FXML
Button exp6;
@FXML
Button exp7;
@FXML
Button salary;
@FXML
Button business;
@FXML
Button property;
@FXML
Button online;
@FXML
Button fund;
@FXML
Button others;
@FXML
Button add;
@FXML
TextField ctg;
@FXML
Button bctg;
@FXML
Label ex1;
@FXML
Label ex2;
@FXML
Label ex3;
@FXML
Label ex4;
@FXML
Label ex5;
@FXML
Label ex6;
@FXML
Label ex7;
@FXML
TextField extext1;
@FXML
Button exbtn1;
@FXML
TextField extext2;
@FXML
Button exbtn2;
@FXML
TextField extext3;
@FXML
Button exbtn3;
@FXML
TextField extext4;
@FXML
Button exbtn4;
@FXML
TextField extext5;
@FXML
Button exbtn5;
@FXML
TextField extext6;
@FXML
Button exbtn6;
@FXML
TextField extext7;
@FXML
Button exbtn7;
@FXML
TextField extext8;
@FXML
Button exbtn8;
@FXML
TextField extext9;
@FXML
Button exbtn9;
@FXML
TextField extext10;
@FXML
Button exbtn10;
@FXML
TextField extext11;
@FXML
Button exbtn11;
@FXML
TextField extext12;
@FXML
Button exbtn12;
@FXML
Label exv1;
@FXML
Label exv2;
@FXML
Label exv3;
@FXML
Label exv4;
@FXML
Label exv5;
@FXML
Label exv6;
@FXML
Label exv7;
@FXML
Label exv8;
@FXML
Label exv9;
@FXML
Label exv10;
@FXML
Label exv11;
@FXML
Label exv12;




/////////////////////////   Earnings   ///////////////////////////
@FXML
AnchorPane earnenter;
@FXML
AnchorPane setted;
@FXML
TextField earn_catg;
@FXML
TextField earn_amount;
@FXML
Button earn_enter;
@FXML
Label earn1;
@FXML
Label earn2;
@FXML
Label earn3;
@FXML
Label earn4;
@FXML
Label earn5;
@FXML
Label earn6;
int earn_turn;
int[] earnings = new int[6];
public void earnings(ActionEvent e) {
  if(e.getSource().equals(salary)) {
		
		earn_turn = 0;
		earn_catg.setText("      Salary");
	}else if (e.getSource().equals(business)) {
		
		earn_turn = 1;
		earn_catg.setText("  Business");
	}else if (e.getSource().equals(property)) {
		
		earn_turn = 2;
		earn_catg.setText("  Property");
	}else if (e.getSource().equals(online)) {
		
		earn_turn = 3;
		earn_catg.setText("      Online");
	}else if (e.getSource().equals(fund)) {
		
		earn_turn = 4;
		earn_catg.setText("      Funds");
	}else if (e.getSource().equals(others)) {
		
		earn_turn = 5;
		earn_catg.setText("      Others");
	}
	earnenter.setStyle("visibility:true");
	earn_enter.setStyle("visibility:true");
	earn_enter.setStyle("-fx-background-color: #c63030");
	earn_catg.setStyle("visibility:true");
	earn_amount.setStyle("visibility:true");
	
	earn_amount.setText(null);
	setted.setStyle("visibility:false");
	Alert Alert = new Alert(AlertType.INFORMATION);
	Alert.setTitle("Set Earning");
	Alert.setHeaderText(" ");
	Alert.setGraphic(earnenter);
	Alert.showAndWait();
	
	
}

public void set_earning(ActionEvent e) {
	
	String earncat = earn_catg.getText().toString();
	String amount_str = earn_amount.getText().toString();
	int money =  0;
	if (earn_amount.getText()==null){
		Toolkit.getDefaultToolkit().beep();
		Alert errorAlert = new Alert(AlertType.ERROR);
		errorAlert.setHeaderText("No Input");
		errorAlert.setContentText("Please Enter Value");
		errorAlert.showAndWait();
	}else {
		
		try {
			
			money = Integer.parseInt(amount_str);
		}catch (NumberFormatException c) {
			Toolkit.getDefaultToolkit().beep();
			Alert errorAlert = new Alert(AlertType.ERROR);
			errorAlert.setHeaderText("Input not valid");
			errorAlert.setContentText("Please Enter a Numeric Value");
			errorAlert.showAndWait();
		}
		
		if(earn_turn==0) {
			if(!earn_catg.getText().isEmpty()) {
				
				salary.setText("       "+earncat);
			}else {
				salary.setText("             Salary");
			}
			earnings[0] = money;
			earn1.setText("$"+amount_str);
		}else if(earn_turn==1) {
            if(!earn_catg.getText().isEmpty()) {
				
				business.setText("       "+earncat);
			}else {
				business.setText("         Business");
			}
			earnings[1] = money;
			earn2.setText("$"+amount_str);
		}else if(earn_turn==2) {
            if(!earn_catg.getText().isEmpty()) {
				
				property.setText("       "+earncat);
			}else {
				property.setText("         Property");
			}
			earnings[2] = money;
			earn3.setText("$"+amount_str);
		}else if(earn_turn==3) {
            if(!earn_catg.getText().isEmpty()) {
				
				online.setText("       "+earncat);
			}else {
				online.setText("             Online");
			}
			earnings[3] = money;
			earn4.setText("$"+amount_str);
		}else if(earn_turn==4) {
            if(!earn_catg.getText().isEmpty()) {
				
				fund.setText("       "+earncat);
			}else {
				fund.setText("             Funds");
			}
			earnings[4] = money;
			earn5.setText("$"+amount_str);
		}else if(earn_turn==5) {
            if(!earn_catg.getText().isEmpty()) {
				
				others.setText("       "+earncat);
			}else {
				others.setText("             Others");
			}
			earnings[5] = money;
			earn6.setText("$"+amount_str);
		}
		
		
		setted.setStyle("visibility: true");
		earn_enter.setStyle("visibility:false");
		earn_catg.setStyle("visibility:false");
		earn_amount.setStyle("visibility:false");
	}
	
}
int exp_count = 0;
int[] expenses = new int[12];
public void dis(ActionEvent e) {
	((Node) e.getSource()).setStyle("visibility:false");
	if(e.getSource().equals(food))
	{
		extext1.setText(null);
		extext1.setStyle("visibility: true");
		exbtn1.setStyle("visibility: true");
		exbtn1.setStyle("-fx-background-color:  #0f32e4");
	}
	else if(e.getSource().equals(cloth))
	{
		extext2.setText(null);
		extext2.setStyle("visibility: true");
		exbtn2.setStyle("visibility: true");
		exbtn2.setStyle("-fx-background-color:  #0f32e4");
	}
	else if (e.getSource().equals(travel))
	{
		extext3.setText(null);
		extext3.setStyle("visibility: true");
		exbtn3.setStyle("visibility: true");
		exbtn3.setStyle("-fx-background-color:  #0f32e4");
	}
	else if (e.getSource().equals(education))
	{
		extext4.setText(null);
	extext4.setStyle("visibility: true");
		exbtn4.setStyle("visibility: true");
		exbtn4.setStyle("-fx-background-color:  #0f32e4");
	}
	else if (e.getSource().equals(utilities))
	{
		extext5.setText(null);
		extext5.setStyle("visibility: true");
		exbtn5.setStyle("visibility: true");
		exbtn5.setStyle("-fx-background-color:  #0f32e4");
	}else if (e.getSource().equals(exp1))
	{
		extext6.setText(null);
		extext6.setStyle("visibility: true");
		exbtn6.setStyle("visibility: true");
		exbtn6.setStyle("-fx-background-color:  #0f32e4");
	}else if (e.getSource().equals(exp2))
	{
		extext7.setText(null);
		extext7.setStyle("visibility: true");
		exbtn7.setStyle("visibility: true");
		exbtn7.setStyle("-fx-background-color:  #0f32e4");
	}else if (e.getSource().equals(exp3))
	{
		extext8.setText(null);
		extext8.setStyle("visibility: true");
		exbtn8.setStyle("visibility: true");
		exbtn8.setStyle("-fx-background-color:  #0f32e4");
	}else if (e.getSource().equals(exp4))
	{
		extext9.setText(null);
		extext9.setStyle("visibility: true");
		exbtn9.setStyle("visibility: true");
		exbtn9.setStyle("-fx-background-color:  #0f32e4");
	}else if (e.getSource().equals(exp5))
	{
		extext10.setText(null);
		extext10.setStyle("visibility: true");
		exbtn10.setStyle("visibility: true");
		exbtn10.setStyle("-fx-background-color:  #0f32e4");
	}else if (e.getSource().equals(exp6))
	{
		extext11.setText(null);
		extext11.setStyle("visibility: true");
		exbtn11.setStyle("visibility: true");
		exbtn11.setStyle("-fx-background-color:  #0f32e4");
	}else if (e.getSource().equals(exp7))
	{
		extext12.setText(null);
		extext12.setStyle("visibility: true");
		exbtn12.setStyle("visibility: true");
		exbtn12.setStyle("-fx-background-color:  #0f32e4");
	}	
}	

public void add(ActionEvent e) {
	
	ctg.setStyle("visibility: true");
	bctg.setStyle("visibility: true");
	bctg.setStyle("-fx-background-color:   #4097d6");
	add.setStyle("visibility: false");
}

String expname[] = new String[12];
public void extra_category(ActionEvent e) {
	
	String Category = ctg.getText().toString();
	if(ctg.getText().isEmpty()) {
		Dialog<String> box = new Dialog<String>();
	    ButtonType type = new ButtonType("Ok", ButtonData.OK_DONE);
	    box.setTitle("Error");
	    box.setContentText("Please Enter a Value");
		box.getDialogPane().getButtonTypes().add(type);
		box.showAndWait();
		
	}else {
		
		if(exp_count==0) {
			
			exp1.setStyle("visibility: true");
			exp1.setStyle("-fx-background-color:      #4097d6");
			exp1.setText(Category);
			ex1.setText(Category);
			expname[5] = Category;
			exp_count++;
		}else if(exp_count==1) {
			
			exp2.setStyle("visibility: true");
			exp2.setStyle("-fx-background-color:     #4097d6");
			exp2.setText(Category);
			ex2.setText(Category);
			expname[6] = Category;
			exp_count++;
		}else if(exp_count==2) {
			
			exp3.setStyle("visibility: true");
			exp3.setStyle("-fx-background-color:     #4097d6");
			exp3.setText(Category);
			ex3.setText(Category);
			expname[7] = Category;
			exp_count++;
		}else if(exp_count==3) {
			
			exp4.setStyle("visibility: true");
			exp4.setStyle("-fx-background-color:     #4097d6");
			exp4.setText(Category);
			ex4.setText(Category);
			expname[8] = Category;
			exp_count++;
		}else if(exp_count==4) {
			
			exp5.setStyle("visibility: true");
			exp5.setStyle("-fx-background-color:     #4097d6");
			exp5.setText(Category);
			ex5.setText(Category);
			expname[9] = Category;
			exp_count++;
		}else if(exp_count==5) {
			
			exp6.setStyle("visibility: true");
			exp6.setStyle("-fx-background-color:     #4097d6");
			exp6.setText(Category);
			ex6.setText(Category);
			expname[10] = Category;
			exp_count++;
		}else if(exp_count==6) {
			
			exp7.setStyle("visibility: true");
			exp7.setStyle("-fx-background-color:     #4097d6");
			exp7.setText(Category);
			ex7.setText(Category);
			expname[11] = Category;
			exp_count++;
		}
		bctg.setStyle("visibility: false");
		ctg.setText(null);
		ctg.setStyle("visibility: false");
		add.setStyle("visibility: true");
		add.setStyle("-fx-background-radius:50.0px");
		add.setStyle("-fx-background-color:    #4097d6");
		
	}
}
    

    public void Recieve_Expenses(ActionEvent e) {
	
    	if(e.getSource().equals(exbtn1)) {
			if (extext1.getText()==null){
				extext1.setPromptText("Enter Amount");
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter Value");
				errorAlert.showAndWait();
			}else{
				String fdstr = extext1.getText();
				try {
				    int ft = Integer.parseInt(fdstr);
					expenses[0] = ft;
				exv1.setText("$"+extext1.getText());
				    
				}catch (NumberFormatException c) {
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("Input not valid");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				extext1.setStyle("visibility: false");
				exbtn1.setStyle("visibility: false");
				food.setStyle("visibility: true");
				food.setStyle("-fx-background-color :   #4097d6");
				extext1.setText(null);
			
			}
			}else if(e.getSource().equals(exbtn2)) {
				if (extext2.getText()==null){
					extext2.setPromptText("Enter Amount");
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("No Input");
					errorAlert.setContentText("Please Enter Value");
					errorAlert.showAndWait();
				}else{
					String fdstr = extext2.getText();
					try {
					    int ft = Integer.parseInt(fdstr);
						expenses[1] = ft;
					exv2.setText("$"+extext2.getText());
					    
					}catch (NumberFormatException c) {
						Toolkit.getDefaultToolkit().beep();
						Alert errorAlert = new Alert(AlertType.ERROR);
						errorAlert.setHeaderText("Input not valid");
						errorAlert.setContentText("Please Enter a Numeric Value");
						errorAlert.showAndWait();
					}
					extext2.setStyle("visibility: false");
					exbtn2.setStyle("visibility: false");
					cloth.setStyle("visibility: true");
					cloth.setStyle("-fx-background-color :   #4097d6");
					extext2.setText(null);
				
				}
				}else if(e.getSource().equals(exbtn3)) {
					if (extext3.getText()==null){
						extext3.setPromptText("Enter Amount");
						Toolkit.getDefaultToolkit().beep();
						Alert errorAlert = new Alert(AlertType.ERROR);
						errorAlert.setHeaderText("No Input");
						errorAlert.setContentText("Please Enter Value");
						errorAlert.showAndWait();
					}else{
						String fdstr = extext3.getText();
						try {
						    int ft = Integer.parseInt(fdstr);
							expenses[2] = ft;
					      exv3.setText("$"+extext3.getText());
						    
						}catch (NumberFormatException c) {
							Toolkit.getDefaultToolkit().beep();
							Alert errorAlert = new Alert(AlertType.ERROR);
							errorAlert.setHeaderText("Input not valid");
							errorAlert.setContentText("Please Enter a Numeric Value");
							errorAlert.showAndWait();
						}
						extext3.setStyle("visibility: false");
						exbtn3.setStyle("visibility: false");
						travel.setStyle("visibility: true");
						travel.setStyle("-fx-background-color :   #4097d6");
						extext3.setText(null);
					
					}
					}else if(e.getSource().equals(exbtn4)) {
						if (extext4.getText()==null){
							extext4.setPromptText("Enter Amount");
							Toolkit.getDefaultToolkit().beep();
							Alert errorAlert = new Alert(AlertType.ERROR);
							errorAlert.setHeaderText("No Input");
							errorAlert.setContentText("Please Enter Value");
							errorAlert.showAndWait();
						}else{
							String fdstr = extext4.getText();
							try {
							    int ft = Integer.parseInt(fdstr);
								expenses[3] = ft;
							exv4.setText("$"+extext4.getText());
							    
							}catch (NumberFormatException c) {
								Toolkit.getDefaultToolkit().beep();
								Alert errorAlert = new Alert(AlertType.ERROR);
								errorAlert.setHeaderText("Input not valid");
								errorAlert.setContentText("Please Enter a Numeric Value");
								errorAlert.showAndWait();
							}
							extext4.setStyle("visibility: false");
							exbtn4.setStyle("visibility: false");
							education.setStyle("visibility: true");
							education.setStyle("-fx-background-color :   #4097d6");
							extext4.setText(null);
						
						}
						}else if(e.getSource().equals(exbtn5)) {
							if (extext5.getText()==null){
								extext5.setPromptText("Enter Amount");
								Toolkit.getDefaultToolkit().beep();
								Alert errorAlert = new Alert(AlertType.ERROR);
								errorAlert.setHeaderText("No Input");
								errorAlert.setContentText("Please Enter Value");
								errorAlert.showAndWait();
							}else{
								String fdstr = extext5.getText();
								try {
								    int ft = Integer.parseInt(fdstr);
									expenses[4] = ft;
								exv5.setText("$"+extext5.getText());
								    
								}catch (NumberFormatException c) {
									Toolkit.getDefaultToolkit().beep();
									Alert errorAlert = new Alert(AlertType.ERROR);
									errorAlert.setHeaderText("Input not valid");
									errorAlert.setContentText("Please Enter a Numeric Value");
									errorAlert.showAndWait();
								}
								extext5.setStyle("visibility: false");
								exbtn5.setStyle("visibility: false");
								utilities.setStyle("visibility: true");
								utilities.setStyle("-fx-background-color :   #4097d6");
								extext5.setText(null);
							
							}
							}else if(e.getSource().equals(exbtn6)) {
								if (extext6.getText()==null){
									extext6.setPromptText("Enter Amount");
									Toolkit.getDefaultToolkit().beep();
									Alert errorAlert = new Alert(AlertType.ERROR);
									errorAlert.setHeaderText("No Input");
									errorAlert.setContentText("Please Enter Value");
									errorAlert.showAndWait();
								}else{
									String fdstr = extext6.getText();
									try {
									    int ft = Integer.parseInt(fdstr);
										expenses[5] = ft;
									exv6.setText("$"+extext6.getText());
									    
									}catch (NumberFormatException c) {
										Toolkit.getDefaultToolkit().beep();
										Alert errorAlert = new Alert(AlertType.ERROR);
										errorAlert.setHeaderText("Input not valid");
										errorAlert.setContentText("Please Enter a Numeric Value");
										errorAlert.showAndWait();
									}
									extext6.setStyle("visibility: false");
									exbtn6.setStyle("visibility: false");
									exp1.setStyle("visibility: true");
									exp1.setStyle("-fx-background-color :   #4097d6");
									extext6.setText(null);
								
								}
								}else if(e.getSource().equals(exbtn7)) {
									if (extext7.getText()==null){
										extext7.setPromptText("Enter Amount");
										Toolkit.getDefaultToolkit().beep();
										Alert errorAlert = new Alert(AlertType.ERROR);
										errorAlert.setHeaderText("No Input");
										errorAlert.setContentText("Please Enter Value");
										errorAlert.showAndWait();
									}else{
										String fdstr = extext7.getText();
										try {
										    int ft = Integer.parseInt(fdstr);
											expenses[6] = ft;
										exv7.setText("$"+extext7.getText());
										    
										}catch (NumberFormatException c) {
											Toolkit.getDefaultToolkit().beep();
											Alert errorAlert = new Alert(AlertType.ERROR);
											errorAlert.setHeaderText("Input not valid");
											errorAlert.setContentText("Please Enter a Numeric Value");
											errorAlert.showAndWait();
										}
										extext7.setStyle("visibility: false");
										exbtn7.setStyle("visibility: false");
										exp2.setStyle("visibility: true");
										exp2.setStyle("-fx-background-color:   #4097d6");
										extext7.setText(null);
									
									}
									}else if(e.getSource().equals(exbtn8)) {
										if (extext8.getText()==null){
											extext8.setPromptText("Enter Amount");
											Toolkit.getDefaultToolkit().beep();
											Alert errorAlert = new Alert(AlertType.ERROR);
											errorAlert.setHeaderText("No Input");
											errorAlert.setContentText("Please Enter Value");
											errorAlert.showAndWait();
										}else{
											String fdstr = extext8.getText();
											try {
											    int ft = Integer.parseInt(fdstr);
												expenses[7] = ft;
										       exv8.setText("$"+extext8.getText());
											    
											}catch (NumberFormatException c) {
												Toolkit.getDefaultToolkit().beep();
												Alert errorAlert = new Alert(AlertType.ERROR);
												errorAlert.setHeaderText("Input not valid");
												errorAlert.setContentText("Please Enter a Numeric Value");
												errorAlert.showAndWait();
											}
											extext8.setStyle("visibility: false");
											exbtn8.setStyle("visibility: false");
											exp3.setStyle("visibility: true");
											exp3.setStyle("-fx-background-color :   #4097d6");
											extext8.setText(null);
										
										}
										}else if(e.getSource().equals(exbtn9)) {
											if (extext9.getText()==null){
												extext9.setPromptText("Enter Amount");
												Toolkit.getDefaultToolkit().beep();
												Alert errorAlert = new Alert(AlertType.ERROR);
												errorAlert.setHeaderText("No Input");
												errorAlert.setContentText("Please Enter Value");
												errorAlert.showAndWait();
											}else{
												String fdstr = extext9.getText();
												try {
												    int ft = Integer.parseInt(fdstr);
													expenses[8] = ft;
												exv9.setText("$"+extext9.getText());
												    
												}catch (NumberFormatException c) {
													Toolkit.getDefaultToolkit().beep();
													Alert errorAlert = new Alert(AlertType.ERROR);
													errorAlert.setHeaderText("Input not valid");
													errorAlert.setContentText("Please Enter a Numeric Value");
													errorAlert.showAndWait();
												}
												extext9.setStyle("visibility: false");
												exbtn9.setStyle("visibility: false");
												exp4.setStyle("visibility: true");
												exp4.setStyle("-fx-background-color :   #4097d6");
												extext9.setText(null);
											
											}
											}else if(e.getSource().equals(exbtn10)) {
												if (extext10.getText()==null){
													extext10.setPromptText("Enter Amount");
													Toolkit.getDefaultToolkit().beep();
													Alert errorAlert = new Alert(AlertType.ERROR);
													errorAlert.setHeaderText("No Input");
													errorAlert.setContentText("Please Enter Value");
													errorAlert.showAndWait();
												}else{
													String fdstr = extext10.getText();
													try {
													    int ft = Integer.parseInt(fdstr);
														expenses[9] = ft;
													exv10.setText("$"+extext10.getText());
													    
													}catch (NumberFormatException c) {
														Toolkit.getDefaultToolkit().beep();
														Alert errorAlert = new Alert(AlertType.ERROR);
														errorAlert.setHeaderText("Input not valid");
														errorAlert.setContentText("Please Enter a Numeric Value");
														errorAlert.showAndWait();
													}
													extext10.setStyle("visibility: false");
													exbtn10.setStyle("visibility: false");
													exp5.setStyle("visibility: true");
													exp5.setStyle("-fx-background-color :   #4097d6");
													extext10.setText(null);
												
												}
												}else if(e.getSource().equals(exbtn11)) {
													if (extext11.getText()==null){
														extext11.setPromptText("Enter Amount");
														Toolkit.getDefaultToolkit().beep();
														Alert errorAlert = new Alert(AlertType.ERROR);
														errorAlert.setHeaderText("No Input");
														errorAlert.setContentText("Please Enter Value");
														errorAlert.showAndWait();
													}else{
														String fdstr = extext11.getText();
														try {
														    int ft = Integer.parseInt(fdstr);
															expenses[10] = ft;
														exv11.setText("$"+extext11.getText());
														    
														}catch (NumberFormatException c) {
															Toolkit.getDefaultToolkit().beep();
															Alert errorAlert = new Alert(AlertType.ERROR);
															errorAlert.setHeaderText("Input not valid");
															errorAlert.setContentText("Please Enter a Numeric Value");
															errorAlert.showAndWait();
														}
														extext11.setStyle("visibility: false");
														exbtn11.setStyle("visibility: false");
														exp6.setStyle("visibility: true");
														exp6.setStyle("-fx-background-color :   #4097d6");
														extext11.setText(null);
													
													}
													}else if(e.getSource().equals(exbtn12)) {
														if (extext12.getText()==null){
															extext12.setPromptText("Enter Amount");
															Toolkit.getDefaultToolkit().beep();
															Alert errorAlert = new Alert(AlertType.ERROR);
															errorAlert.setHeaderText("No Input");
															errorAlert.setContentText("Please Enter Value");
															errorAlert.showAndWait();
														}else{
															String fdstr = extext12.getText();
															try {
															    int ft = Integer.parseInt(fdstr);
																expenses[11] = ft;
															exv12.setText("$"+extext12.getText());
															    
															}catch (NumberFormatException c) {
																Toolkit.getDefaultToolkit().beep();
																Alert errorAlert = new Alert(AlertType.ERROR);
																errorAlert.setHeaderText("Input not valid");
																errorAlert.setContentText("Please Enter a Numeric Value");
																errorAlert.showAndWait();
															}
															extext12.setStyle("visibility: false");
															exbtn12.setStyle("visibility: false");
															exp7.setStyle("visibility: true");
															exp7.setStyle("-fx-background-color :   #4097d6");
															extext12.setText(null);
														
														}
														}
}
/////////////////////////////   Savings   /////////////////////////////////    
    @FXML
    Label totalearn;
    @FXML
    Label totalexpense;
    @FXML
    Label savings;
    @FXML
    Label goal;
    @FXML
    Label progress;
    @FXML
    Button set_saving;
    @FXML
    Button prompt_savings;
    @FXML
    Button Calculate;
    @FXML
    TextField addsaving;
    @FXML
    AreaChart budget;
    
    int saving_goal ;
    int total_expenses;
    int total_earnings;
    int total_savings;
    int progress_percent;
    double sprogress;
    boolean save = false;
    boolean queuestart = false;
    int Qcount = 0;
    public void PSaving(ActionEvent e) {
    	
    	prompt_savings.setStyle("visibility:false");
    	set_saving.setStyle("visibility:true");
    	set_saving.setStyle("-fx-background-color:  #00a800");
    	addsaving.setStyle("visibility:true");
    }
    
    public void set_saving(ActionEvent e) {
    	
    	String sg = addsaving.getText().toString();
    	try {
		    saving_goal = Integer.parseInt(sg);
		    goal.setText("$"+addsaving.getText());
		    prompt_savings.setStyle("visibility:true");
	    	set_saving.setStyle("visibility:false");
	    	prompt_savings.setStyle("-fx-background-color:    #4097d6");
	    	addsaving.setStyle("visibility:false");
	    	save = true;
		    
		}catch (NumberFormatException c) {
			Toolkit.getDefaultToolkit().beep();
			Alert errorAlert = new Alert(AlertType.ERROR);
			errorAlert.setHeaderText("Input not valid");
			errorAlert.setContentText("Please Enter a Numeric Value");
			errorAlert.showAndWait();
		}
    }
    
    SavingQueue SQ = new SavingQueue(10);
    public void Calculate_Budget(ActionEvent e) {
    	
    	XYChart.Series<String,Number> series = new XYChart.Series<>();
    	total_expenses = 0;
    	total_earnings = 0;
    	total_savings = 0;
    	for(int i=0 ; i<expenses.length ; i++) {
    		
    		total_expenses += expenses[i];
    	}
    	
    	for(int i=0 ; i<earnings.length ; i++) {
    		
    		total_earnings += earnings[i];
    	}
    	
    	total_savings = total_earnings - total_expenses;
    	double totsav = (double)total_savings;
    sprogress = Math.round(((double)total_savings/(double)saving_goal)*100);
    System.out.println(sprogress);
    if(!queuestart) {
		
		double var1 = 0.3*totsav;
		double var2 = 0.7*totsav;
		SQ.EnQueue(var1);
		SQ.EnQueue(var2);
		SQ.EnQueue(totsav);
		queuestart = true;
		Qcount += 1;
	}else {
		
		if(SQ.isfull()) {
			
			Qcount += 1;
			SQ.EnQueue(totsav);
		}else {
			
			
			SQ.DeQueue();
			SQ.EnQueue(totsav);
		}
	}
    
    if(total_expenses==0||total_earnings==0) {
    	
    	Alert errorAlert = new Alert(AlertType.ERROR);
		errorAlert.setHeaderText("Data Not Entered");
		errorAlert.setContentText("Please Enter your expenses and earnings");
		errorAlert.showAndWait();
    }else {
    	
    	if(save) {
        	
       	 totalexpense.setText("$"+Integer.toString(total_expenses));
       	 totalearn.setText("$"+Integer.toString(total_earnings));
       	 savings.setText("$"+Integer.toString(total_savings));
       	    
       	    if(sprogress>=100) {
       	    	
       	    	progress.setText("100%");
       	    	progress.setTextFill(Color.GREEN);
       	    }else if(sprogress>=90&&sprogress<100) {
       	    	
       	    	progress.setText(Double.toString(sprogress)+"%");
       	    	progress.setTextFill(Color.LIGHTGREEN);
       	    }else if(sprogress>=60&&sprogress<90) {
       	    	
       	    	progress.setText(Double.toString(sprogress)+"%");
       	    	progress.setTextFill(Color.BLUE);
       	    }else if(sprogress>20&&sprogress<60) {
       	    	
       	    	progress.setText(Double.toString(sprogress)+"%");
       	    	progress.setTextFill(Color.ORANGE);
       	    }else if(sprogress>=1&&sprogress<=20) {
       	    	
       	    	progress.setText(Double.toString(sprogress)+"%");
       	    	progress.setTextFill(Color.RED);
       	    }else if(sprogress<1) {
       	    	
       	    	progress.setText("0%");
       	    	progress.setTextFill(Color.RED);
       	    }
       	    
       	 String str = " ";
			for(int i=0 ; i<=Qcount+1 ; i++) {
				
				series.getData().add(new XYChart.Data<String,Number>(str,SQ.arr[i]));
				str += " ";
			}
			budget.setStyle("-fx-fill: green;");
			budget.getData().clear();
			budget.getData().add(series);
       }else {
       	
       	Alert errorAlert = new Alert(AlertType.ERROR);
   		errorAlert.setHeaderText("Goal Not Set");
   		errorAlert.setContentText("Please Set Your Saving Goal");
   		errorAlert.showAndWait();
       }
    }
    	
    }
    
    class SavingQueue{
    	
   	 int Front=-1,Rear=-1,Size;
   	 double[] arr;
   	 int ac = -1;
   	 public SavingQueue(int s){
   	 arr = new double[s];
   	 Size=s;
   	 }
   	 public double Access() {
   		 
			ac = (ac+1)%Size;
			return arr[ac];
   	 }
   	 public void EnQueue(double d){
   	 if(Front==-1&&Rear==-1){
   	 arr[++Front]=d;
   	 Rear++;
   	 return;
   	 }else if(Front==0&&Rear==Size-1){
   	 System.out.println("Queue is full");
   	 return;
   	 }else{
   	 arr[++Rear]=d;
   	 return;
   	}
  }
   	 public boolean isfull() {
   		 
   		 if(Front==0&&Rear==Size-1) {
   			 
   			 return false;
   		 }else {
   			 
   			 return true;
   		 }
   	 }
   	 public void DeQueue(){
   	 for(int i=0;i<=Rear-1;i++){
   	 arr[i]=arr[i+1];
   	 }
   	 arr[Rear]=0;
   	  Rear--;
   	 }
   }
    
////////////////////   AI Suggestions   /////////////////////
@FXML
AnchorPane AI;
@FXML
Button suggest;
@FXML
Button Report;
@FXML
AnchorPane Budget_Report;
@FXML
TextArea TA;
public void Give_Suggestions(ActionEvent e) {
	
	budget.setStyle("visibility: false");
	AI.setStyle("visibility: true");
	expname[0] = "Food";
	expname[1] = "Clothes";
	expname[2] = "Travel";
	expname[3] = "Education";
	int ex[] = new int[12];
	for(int i=0 ; i<12 ; i++)
	ex[i] = expenses[i];
	
	ex[0] = 0;
	ex[2] = 0;
	ex[4] = 0;
    int p = earnings[2];
    int o = earnings[3];
    int f = earnings[4];
    int b = earnings[1];
    
    for(int i=0 ; i<ex.length ; i++) {
			
			for(int j=i+1 ; j<ex.length ; j++) {
				
				if(ex[i]<ex[j]) {
					
					int temp = ex[i];
					ex[i] = ex[j];
					ex[j] = temp;
					String temp2 = expname[i];
					expname[i] = expname[j];
					expname[j] = temp2;
				}
			}
		}
    String es1 = expname[0];
    String es2 = expname[1];
    String es3 = expname[2];
    System.out.println(es1);
    System.out.println(es2);
    System.out.println(es3);
    int e1 = ex[0];
    int e2 = ex[1];
    int e3 = ex[2];
    for(int i=0 ; i<12 ; i++)
    System.out.println("--> "+expname[i]);
    boolean exb1=false,exb2=false;
    if(ex[1]>0) {
    	exb1 = true;
    }else {}
    if(ex[2]>0)
    exb2 = true;
    
    if(sprogress<=20) {
    	
          if(b>0) {
        	
        	if(f>0) {
        		
        		if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        			}else {
        				
                        if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing your Fundings along with property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your Fundings along with property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                         if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing your Fundings along with \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your Fundings along with \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        				
        		}
        	}else {
        		
                 if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        			}else {
        				
                        if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                         if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your online income\ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing your online income\ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your online income\ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        				
        		}
        	}
      }else {
        	
    	  if(f>0) {
      		
      		if(p>0) {
      			
      			if(o>0) {
      				
      				if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your fundings along with your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your fundings along with your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your fundings along with your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      			}else {
      				
                      if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your fundings along with your property income\nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your fundings along with your property income\nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your fundings along with your property income \nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      		}
      			}else if(p<=0&&o>0) {
      			
                      if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your fundings along with your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your fundings along with your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your fundings along with your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      				
      		}
      	}else {
      		
            if(p>0) {
      			
      			if(o>0) {
      				
      				if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      			}else {
      				
                      if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your property income\nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your property income\nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your property income \nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      		}
      			}else if(p<=0&&o>0) {
      			
                      if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      				
      		}
      	}
        }
    	
    }else if(sprogress>20&&sprogress<=70) {
    	
    	if(b>0) {
        	
        	if(f>0) {
        		
        		if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        				}
        			}else {
        				
                       if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        				}
        			}
        		}else if(p<=0&&o>0) {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \ninto your online income in your \nbusiness so it grow and you earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your online income in your \nbusiness so it grow and you earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property online income in your \nbusiness so it grow and you earn more.");
    				}
        		}
        	}else {
        		
                 if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        				}
        			}else {
        				
                       if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        				}
        			}
        		}else if(p<=0&&o>0) {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your online income in your \nbusiness so it grow and you earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your online income in your \nbusiness so it grow and you earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property online income in your \nbusiness so it grow and you earn more.");
    				}
        		}
        	}
        }else {
        	
               if(f>0) {
        		
        		if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \nyour property and online income to start a \nbusiness so you can earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your property and online income to start a \nbusiness so you can earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property and online income to start a \nbusiness so you can earn more.");
        				}
        			}else {
        				
                       if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \ninto your property income to start a\nbusiness so you can earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your property income to start \nbusiness so you can earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property income to start \nbusiness so you can earn more.");
        				}
        			}
        		}else if(p<=0&&o>0) {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \ninto your online income to start \nbusiness so you can earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your online income to start \nbusiness so you can earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property online income to start \nbusiness so you can earn more.");
    				}
        		}
        	}else {
        		
                 if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your property and online income to start \nbusiness so you can earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your property and online income to start \nbusiness so you can earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property and online income to start \nbusiness so you can earn more.");
        				}
        			}else {
        				
                       if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your property income to start \nbusiness so you can earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your property income to start \nbusiness so you can earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property income to start \nbusiness so you can earn more.");
        				}
        			}
        		}else if(p<=0&&o>0) {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your online income to start \nbusiness so you can earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your online income to start \nbusiness so you can earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property online income to start \nbusiness so you can earn more.");
    				}
        		}
        	}
        }
    }else if(sprogress>70&&sprogress<=90) {
    	
          if(b>0) {
        	
        	if(f>0) {
        		
        		if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more.");
        				}
        			}else {
        				
                          if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with property\nincome into your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your Fundings along with property\nincome into your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your Fundings along with property\nincome into your business so, it will grow and \nyou earn more.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                          if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with\nonline income into your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your Fundings along with\nonline income into your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your Fundings along with\nonline income into your business so, it will grow and \nyou earn more.");
        				}
        		}
        	}else {
        		
                 if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more.");
        				}
        			}else {
        				
                          if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your property\nincome into your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your property\nincome into your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your property\nincome into your business so, it will grow and \nyou earn more.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                          if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Funding online income \ninto your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your online income \ninto your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your online income \ninto your business so, it will grow and \nyou earn more.");
        				}
        		}
        	}
        }else {
        	
             if(f>0) {
        		
        		if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your fundings and your property and online income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your property and online income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your property and online income\nstart some business so, it will grow and \nyou earn more.");
        				}
        			}else {
        				
                        if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your fundings and your property income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your property income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your property income\nstart some business so, it will grow and \nyou earn more.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                         if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your fundings and your online income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your online income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your online income\nstart some business so, it will grow and \nyou earn more.");
        				}
        		}
        	}else {
        		
                if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your property and online income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your property and online income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your property and online income\nstart some business so, it will grow and \nyou earn more.");
        				}
        			}else {
        				
                        if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your property income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your property income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your property income\nstart some business so, it will grow and \nyou earn more.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                         if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your online income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your online income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your online income\nstart some business so, it will grow and \nyou earn more.");
        				}
        		}
        	}
        }
    }else if(sprogress>=90){
    	
    	if(exb1) {
			
			if(exb2) {
				
				TA.setText("You are already very near to you goal \n just minimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you will be able to\nachieve your Saving Goal.");
			}else {
				
				TA.setText("You are already very near to you goal \n just minimize your expenses of "+es1+", "+es2+"\nand with this you will be able to\nachieve your Saving Goal.");
			}
		}else {
			
			TA.setText("You are already very near to you goal \n just minimize your expenses of "+es1+", "+es2+" \nand with this you will be able to\nachieve your Saving Goal.");
		}
    	
    }
    
	
}

public void Back_to_Report(ActionEvent e) {
    
	Calculate_Budget(e);
	budget.setStyle("visibility: true");
	AI.setStyle("visibility: false");
}

/////////////////////////////////   Event Plan   ////////////////////////////////////////////

@FXML
Button eventname;
@FXML
TextField enterevname;
@FXML
Button setevname;
@FXML
Label EvName;
@FXML
TextField evB1;
@FXML
TextField evB2;
@FXML
TextField evB3;
@FXML
TextField evB4;
@FXML
TextField evB5;
@FXML
TextField evB6;
@FXML
TextField evB7;
@FXML
TextField evB8;
@FXML
Button extevB;
@FXML
TextField enterexternal;
@FXML
Button setextB;
@FXML
Label evTotalExpense;
@FXML
Label evTotalEarning;
@FXML
Label evTotalSaving;
@FXML
Label EventExpenditure;
@FXML
Label EventBudgets;
@FXML
Label Probability;
@FXML
Button CalculateEvent;
@FXML
ProgressBar bar;
@FXML
BubbleChart bubble;
@FXML
Button evBack;

int event_ARR[] = new int[8];
int EventExpenses = 0;
int EventBudget = 0;
int ExternalBudget = 0;
public void set_eventname(ActionEvent e) {
	
	EvName.setText("      "+enterevname.getText().toString());
	enterevname.setStyle("visibility:false");
	setevname.setStyle("visibility:false");
	eventname.setStyle("visibility:true");
	eventname.setStyle("-fx-background-color:    #4097d6");
	
}

public void prompt_EventName(ActionEvent e) {
	
	eventname.setStyle("visibility:false");
	enterevname.setStyle("visibility:true");
	setevname.setStyle("visibility:true");
	setevname.setStyle("-fx-background-color:   #0f32e4");
}

public void prompt_ExternalBudget(ActionEvent e) {
	
	extevB.setStyle("visibility: false");
	enterexternal.setStyle("visibility:true");
	setextB.setStyle("visibility:true");
	setextB.setStyle("-fx-background-color:   #0f32e4");
}

public void set_ExternalBudget(ActionEvent e) {
	
	try {
	    
		ExternalBudget = Integer.parseInt(enterexternal.getText().toString());
		enterexternal.setStyle("visibility:false");
		setextB.setStyle("visibility:false");
		extevB.setStyle("visibility:true");
		extevB.setStyle("-fx-background-color:    #4097d6");
	}catch (NumberFormatException c) {
		Toolkit.getDefaultToolkit().beep();
		Alert errorAlert = new Alert(AlertType.ERROR);
		errorAlert.setHeaderText("Input not valid");
		errorAlert.setContentText("Please Enter a Numeric Value");
		errorAlert.showAndWait();
	}
	
}

public void CalculateEvent(ActionEvent e) {
	
	EventExpenses = 0;
	XYChart.Series evseries = new XYChart.Series<>();
	try {
		event_ARR[0] = Integer.parseInt(evB1.getText().toString());
		event_ARR[1] = Integer.parseInt(evB2.getText().toString());
		event_ARR[2] = Integer.parseInt(evB3.getText().toString());
		event_ARR[3] = Integer.parseInt(evB4.getText().toString());
		event_ARR[4] = Integer.parseInt(evB5.getText().toString());
		event_ARR[5] = Integer.parseInt(evB6.getText().toString());
		event_ARR[6] = Integer.parseInt(evB7.getText().toString());
		event_ARR[7] = Integer.parseInt(evB8.getText().toString());
		
		EventBudget = total_savings + ExternalBudget;
		for(int i=0 ; i<8 ; i++) {
			
			evseries.getData().add(new XYChart.Data(event_ARR[i],EventBudget+event_ARR[i],EventBudget-event_ARR[i]));
			System.out.println(EventBudget-event_ARR[i]);
			EventExpenses += event_ARR[i];
			
		}
		
		bubble.getData().add(evseries);
		bubble.setStyle("-fx-accent:   #3ac78b");
		
		EventExpenditure.setText("  $"+Integer.toString(EventExpenses));
		EventBudgets.setText("  $"+Integer.toString(EventBudget));
		
		double percent = ((double)EventBudget/(double)EventExpenses)*100;
		double evprob = percent/100;
		
		if(percent>=100) {
			
			bar.setProgress(1);
			bar.setStyle("-fx-accent:  green");
			Probability.setText("100%");
		}else if(percent>20 && percent<=100) {
			
			bar.setProgress(evprob);
			bar.setStyle("-fx-accent:    #4097d6");
			Probability.setText(String.format("%.1f%%",percent));
		}else if(percent<=20) {
			bar.setProgress(evprob);
			bar.setStyle("-fx-accent:  red");
			Probability.setText(String.format("%.1f%%",percent));
		}
		
	}catch (NumberFormatException c) {
		Toolkit.getDefaultToolkit().beep();
		Alert errorAlert = new Alert(AlertType.ERROR);
		errorAlert.setHeaderText("Input not valid");
		errorAlert.setContentText("Please Enter a Numeric Value");
		errorAlert.showAndWait();
	}
	
}

/////////////////////     Done Missed Task /////////////////
@FXML
Button CalBack;
@FXML
Button refresh;
@FXML
ImageView i1;
@FXML
ImageView i2;
@FXML
ImageView i3;
@FXML
ImageView i4;
@FXML
ImageView i5;
@FXML
ImageView i6;
@FXML
ImageView i7;
@FXML
ImageView i8;
@FXML
ImageView i9;

@FXML
ImageView i10;

@FXML
ImageView i11;

@FXML
ImageView i12;

@FXML
ImageView i13;

@FXML
ImageView i14;

@FXML
ImageView i15;

@FXML
ImageView i16;

@FXML
Button add11;
@FXML
Button add12;
@FXML
Button add13;
@FXML
Button add14;
@FXML
Button add15;
@FXML
Button add16;
@FXML
Button add17;
@FXML
LineChart<String,Number> routine_progress;
@FXML
CategoryAxis cx;
@FXML
NumberAxis ns;
SavingQueue rarray = new SavingQueue(15);
XYChart.Series<String,Number> series1 = new XYChart.Series<>();
int routine_count=0;
public void CalBacker() {
	
	Main.setStyle("visibility: true");
	EventTracker.setStyle("visibility: false");
	myGrid.setVisible(false);
}
public void mark_routine(ActionEvent e) {	
series1.setName("Routine Progress");
if(e.getSource().equals(done1)) {
done1.setVisible(false);
miss1.setVisible(false);
add1.setVisible(false);
i1.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(5);
}else {
rarray.DeQueue();
rarray.EnQueue(5);
}
}
if(e.getSource().equals(done2)) {
done2.setVisible(false);
miss2.setVisible(false);
add11.setVisible(false);
i2.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(10);
}else {
rarray.DeQueue();
rarray.EnQueue(10);
}
}
if(e.getSource().equals(done3)) {
done3.setVisible(false);
miss3.setVisible(false);
add12.setVisible(false);
i3.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(15);
}else {
rarray.DeQueue();
rarray.EnQueue(15);
}
}
if(e.getSource().equals(done4)) {
done4.setVisible(false);
miss4.setVisible(false);
add13.setVisible(false);
i4.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(20);
}else {
rarray.DeQueue();
rarray.EnQueue(20);
}
}
if(e.getSource().equals(done5)) {
done5.setVisible(false);
miss5.setVisible(false);
add14.setVisible(false);
i5.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(25);
}else {
rarray.DeQueue();
rarray.EnQueue(25);
}
}
if(e.getSource().equals(done6)) {
done6.setVisible(false);
miss6.setVisible(false);
add15.setVisible(false);
i6.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(30);
}else {
rarray.DeQueue();
rarray.EnQueue(30);
}
}
if(e.getSource().equals(done7)) {
done7.setVisible(false);
miss7.setVisible(false);
add16.setVisible(false);
i7.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(35);
}else {
rarray.DeQueue();
rarray.EnQueue(35);
}
}
if(e.getSource().equals(done8)) {
done8.setVisible(false);
miss8.setVisible(false);
add17.setVisible(false);
i8.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(40);
}else {
rarray.DeQueue();
rarray.EnQueue(40);
}
}
if(e.getSource().equals(miss1)) {
done1.setVisible(false);
miss1.setVisible(false);
add1.setVisible(false);
i9.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(8);
}else {
rarray.DeQueue();
rarray.EnQueue(8);
}
}
if(e.getSource().equals(miss2)) {
done2.setVisible(false);
miss2.setVisible(false);
add11.setVisible(false);
i10.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(7);
}else {
rarray.DeQueue();
rarray.EnQueue(7);
}
}
if(e.getSource().equals(miss3)) {
done3.setVisible(false);
miss3.setVisible(false);
add12.setVisible(false);
i11.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(6);
}else {
rarray.DeQueue();
rarray.EnQueue(6);
}
}
if(e.getSource().equals(miss4)) {
done4.setVisible(false);
miss4.setVisible(false);
add13.setVisible(false);
i12.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(5);
}else {
rarray.DeQueue();
rarray.EnQueue(5);
}
}
if(e.getSource().equals(miss5)) {
done5.setVisible(false);
miss5.setVisible(false);
add14.setVisible(false);
i13.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(4);
}else {
rarray.DeQueue();
rarray.EnQueue(4);
}
}
if(e.getSource().equals(miss6)) {
done6.setVisible(false);
miss6.setVisible(false);
add15.setVisible(false);
i14.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(3);
}else {
rarray.DeQueue();
rarray.EnQueue(3);
}
}
if(e.getSource().equals(miss7)) {
done7.setVisible(false);
miss7.setVisible(false);
add16.setVisible(false);
i15.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(2);
}else {
rarray.DeQueue();
rarray.EnQueue(2);
}
}
if(e.getSource().equals(miss8)) {
done8.setVisible(false);
miss8.setVisible(false);
add17.setVisible(false);
i16.setVisible(true);
if(rarray.isfull()) {
routine_count++;
rarray.EnQueue(1);
}else {
rarray.DeQueue();
rarray.EnQueue(1);
}
}
String rp = " ";
for(int i=0;i<routine_count;i++) {
series1.getData().add(new XYChart.Data<String,Number>(rp,rarray.arr[i]));
rp += " ";
}
routine_progress.getData().add(series1);

}
public void refresh_button(ActionEvent e) {
i1.setVisible(false);
i2.setVisible(false);
i3.setVisible(false);
i4.setVisible(false);
i5.setVisible(false);
i6.setVisible(false);
i7.setVisible(false);
i8.setVisible(false);
i9.setVisible(false);
i10.setVisible(false);
i11.setVisible(false);
i12.setVisible(false);
i13.setVisible(false);
i14.setVisible(false);
i15.setVisible(false);
i16.setVisible(false);
done1.setVisible(true);
done2.setVisible(true);
done3.setVisible(true);
done4.setVisible(true);
done5.setVisible(true);
done6.setVisible(true);
done7.setVisible(true);
done8.setVisible(true);
miss1.setVisible(true);
miss2.setVisible(true);
miss3.setVisible(true);
miss4.setVisible(true);
miss5.setVisible(true);
miss6.setVisible(true);
miss7.setVisible(true);
miss8.setVisible(true);
add1.setVisible(true);
add11.setVisible(true);
add12.setVisible(true);
add13.setVisible(true);
add14.setVisible(true);
add15.setVisible(true);
add16.setVisible(true);
add17.setVisible(true);
}

/////////////////////////////////////////////////   Event Tracker   ///////////////////////////////////////////////////
@FXML
Button cancel_T;
@FXML
Button Close_btn;
@FXML
Button Del_Task1;
@FXML
TextArea Txt_Task_Area;
@FXML
TextArea Scheduled_Task;
@FXML
TextArea show_Task;
@FXML
AnchorPane Dialogue_Task;
@FXML
AnchorPane Main_Pane;
@FXML 
Label movDate;
@FXML
Label theDate;
@FXML
GridPane myGrid;
@FXML
Button Add_Task;
@FXML 
Button nextbtn;
@FXML
Button prevbtn;
@FXML
Button create_T;
static int k=0;
static int y=0;
int ny=0;
static int b=0;
public String Current_Date;
Thread thread;

boolean Flag=false;
private volatile boolean stop=false;

public void LogOUT(ActionEvent e){
 if(e.getSource().equals(Close_btn)){
	 Platform.exit();
	 thread.stop();
 }
}
public void Alarm_Task(){
 String Status_Date=LocalDate.now().getDayOfMonth()+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear());
 if(Status_Date.equals(Current_Date))
 {
		String tsk="";
		File f = new File(Current_Date+".txt");
		try {
			FileReader fr = new FileReader(f);
			 int i;    
	          while((i=fr.read())!=-1)   
	          {
	        	  tsk=tsk+((char)i);  
	          }
	      
			fr.close();
			if(tsk.equals(""))
			{
				Scheduled_Task.setText("");
			}
			else
			{
				 Scheduled_Task.setText("the Current Task for today is \n"+tsk);
			}
			

		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
 }
 else
 {
	 Scheduled_Task.setText("");
 }
}

public void TheTasks (ActionEvent e){
 
 if(e.getSource().equals(Del_Task1)){
	
	 
	 int i =0;
		
		for(Node node :myGrid.getChildren()){

		if(i>6){
			
			if(node instanceof StackPane){
				
				StackPane pane =(StackPane)node;
				String Temp=node.getStyle();
				int count=0;
				int Num1 = 0;
				int Num2 = 0;
				for(int j=0;j<Temp.length();j++){
					System.out.print(Temp.charAt(j));
					if(Temp.charAt(j)==':'){
						Num1=j;
					}
					if(Temp.charAt(j)==';'){
						Num2=j;
						count++;
						if(count==2)
						{
							//count=0;
							break;	
						}
					
					}
				}
				String str1=Temp.substring(Num1+1,Num2 );
				if(str1.equals("orange"))
				{
					
					Label l12= (Label) pane.getChildren().get(0);
					String str2=l12.getText()+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear());
					
					
					
					try {
						PrintWriter pw = new PrintWriter(str2+".txt");
						pw.close();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					Change_paneColour(pane,"white");
				}
						
				//System.out.println("the color is ->"+str1);
				
			
			}
		}
		else
		{
			i++;
		}
	}
		Alarm_Task();
 }
	
	if(e.getSource().equals(cancel_T))
	{
		Dialogue_Task.setVisible(false);
		create_T.setVisible(false);
		cancel_T.setVisible(false);
		Txt_Task_Area.setVisible(false);
	}
	if(e.getSource().equals(Add_Task))
	{ 	
		Dialogue_Task.setVisible(true);
		create_T.setVisible(true);
		cancel_T.setVisible(true);
		Txt_Task_Area.setVisible(true);
	}
	if(e.getSource().equals(create_T))
	{ 	String str=Txt_Task_Area.getText();
		 int i =0;
			
			for(Node node :myGrid.getChildren()){
				
				
			if(i>6)
			{
				
			
				if(node instanceof StackPane)
				{
					
					StackPane pane =(StackPane)node;
					String Temp=node.getStyle();
					int count=0;
					int Num1 = 0;
					int Num2 = 0;
					for(int j=0;j<Temp.length();j++)
					{
						System.out.print(Temp.charAt(j));
						if(Temp.charAt(j)==':')
						{
							Num1=j;
				//			System.out.println("i got this at"+j);
						}
						if(Temp.charAt(j)==';')
						{
							Num2=j;
				//			System.out.println("i got this at"+j);
							count++;
							if(count==2)
							{
								//count=0;
								break;	
							}
						
						}
					}
					String str1=Temp.substring(Num1+1,Num2 );
					if(str1.equals("orange"))
					{
						Change_paneColour(pane,"red");
						//Label l1=(Label)pane.getChildren().get(0);
					//	theDate.setText(l1.getText()+"/"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"/"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear()));
						Label l12= (Label) pane.getChildren().get(0);
						String str2=l12.getText()+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear());
						System.out.println(str2+"hey see this!!!...........");
						File f = new File(str2+".txt");
						try {
							FileWriter fw = new FileWriter(f);
							fw.write(Txt_Task_Area.getText());
							Txt_Task_Area.setText(null);
							fw.close();
				System.out.println("file is successfully created");
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
						System.out.println(theDate);
					}
							
					//System.out.println("the color is ->"+str1);
					
				
				}
			}
			else
			{
				i++;
			}
		}
		
			Dialogue_Task.setVisible(false);
			create_T.setVisible(false);
			cancel_T.setVisible(false);
			Txt_Task_Area.setVisible(false);
			Alarm_Task();
	}
	
	}
public void Timenow(){

System.out.println("time should show");
 thread = new Thread ( () ->{
	SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
	while(!stop)
	{
		
		try {
			Thread.sleep(1);
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		final String Timenow = sdf.format(new Date());
		Platform.runLater(()->{
			movDate.setText(Timenow);
		});
	}
});	
thread.start();
}

@FXML
public void initialize() {
	
	
	Timenow();
	
	Add_Task.setVisible(false);
int dayS=LocalDate.now().getDayOfMonth();
int Year=LocalDate.now().getYear();
int Month=LocalDate.now().getMonthValue();
int Days=LocalDate.now().getDayOfMonth();

	theDate.setText(Integer.toString(dayS)+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear()));
	Current_Date=theDate.getText();
	Alarm_Task();
	
	
	for(int i =0;i<=6;i++){
		 String str=LocalDate.now().getDayOfWeek().of(i+1).toString();
		Label l1 = new Label(str);
		
		l1.setFont(new Font("Arial",10));
	
		StackPane pane = new StackPane();
		pane.getChildren().add(l1);
		myGrid.add(pane, i, 0);
		myGrid.setStyle("-fx-background-color:white;");
	}
				int Start_Ind = 0;
				int End_Ind=LocalDate.now().lengthOfMonth()+1;
				boolean flag=false;
  String Day_first_Name=LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonthValue(), 1).getDayOfWeek().toString();
			for(int j=0;j<=6;j++){
				 String str=LocalDate.now().getDayOfWeek().of(j+1).toString();
				 if(Day_first_Name.equals(str))
				 {
					 Start_Ind=j;
			 }
		}
		int index=1;
		 for(int r=1;r<=6;r++) {
			 for(int c=0;c<=6;c++){
				 if(index==End_Ind){
					 break;
				 }
                if(c==Start_Ind){
					 flag=true;
				 }
				 if(flag==true)
				 {
					 Label l2 = new Label(Integer.toString(index++));
					 l2.setFont(new Font("Arial",20));
					 StackPane pane = new StackPane();
						pane.getChildren().add(l2);
						pane.setStyle("-fx-background-color:;-fx-border-color:;-fx-border-width:2;");
						Change_paneColour(pane,"white");
						myGrid.add(pane, c, r);
					
				 }
			 }
		 }

		 InitGo();
		 Initialize_Filing_Color();
		
		
}

public void Initialize_Border_Color(){
	 int i =0;
	
	for(Node node :myGrid.getChildren()){

	if(i>6){
		if(node instanceof StackPane)
		{
			
			StackPane pane =(StackPane)node;
			String Temp=node.getStyle();
			int count=0;
			int Num1 = 0;
			int Num2 = 0;
			for(int j=0;j<Temp.length();j++)
			{
				System.out.print(Temp.charAt(j));
				if(Temp.charAt(j)==':')
				{
					Num1=j;
				}
				if(Temp.charAt(j)==';')
				{
					Num2=j;
					count++;
					if(count==2)
					{
						//count=0;
						break;	
					}
				
				}
			}
			String str1=Temp.substring(0, Num1+1);
			
			String str2=Temp.substring(Num2);
			pane.setStyle(str1+str2);
		}
	}else{
		i++;
	}
}
}


public void Initialize_Filing_Color()
{
	 int i =0;
	
	for(Node node :myGrid.getChildren()){
	if(i>6){
		
		if(node instanceof StackPane){
			
			StackPane pane =(StackPane)node;
			Label l12= (Label) pane.getChildren().get(0);
			String str2=l12.getText()+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear());
			
			File f = new File(str2+".txt");
			if(f.length()!=0)
			{
				Change_paneColour(pane,"red");
			}
		}
	}
	else
	{
		i++;
	}
}
}



public void Change_paneColour(StackPane node,String Col)
{
	String Temp=node.getStyle();
	int Num1 = 0;
	int Num2 = 0;
	for(int i=0;i<Temp.length();i++)
	{
		System.out.print(Temp.charAt(i));
		if(Temp.charAt(i)==':')
		{
			Num1=i;
			System.out.println("i got this at"+i);
		}
		if(Temp.charAt(i)==';')
		{
			Num2=i;
			System.out.println("i got this at"+i);
			break;
		}
	}
	String str1=Temp.substring(0, Num1+1);
	
	String str2=Temp.substring(Num2);
	//System.out.println(str1+"is string1");
	//System.out.println(str2+"is string2");
//	System.out.println(str1+"blue"+str2);
	node.setStyle(str1+Col+str2);
	
	
}
public String Get_paneColour(StackPane node)
{
	String Col;
	String Temp=node.getStyle();
	int Num1 = 0;
	int Num2 = 0;
	for(int i=0;i<Temp.length();i++)
	{
		System.out.print(Temp.charAt(i));
		if(Temp.charAt(i)==':')
		{
			Num1=i;
			System.out.println("i got this at"+i);
		}
		if(Temp.charAt(i)==';')
		{
			Num2=i;
			System.out.println("i got this at"+i);
			break;
		}
	}
	String str1=Temp.substring(Num1+1, Num2);
	return str1;
	
}

public void InitGo()
{
	 int i =0;
		
		for(Node node :myGrid.getChildren()){
			
			System.out.println(node+"right here");
		if(i>6){
			if(node instanceof StackPane){
				
				StackPane pane =(StackPane)node;
				pane.setOnMousePressed(new EventHandler<MouseEvent>() {

					@Override
					public void handle(MouseEvent arg0) {
						Initialize_Border_Color();
						
						
						
						
						String Temp=node.getStyle();
						int count=0;
						int Num1 = 0;
						int Num2 = 0;
						for(int i=0;i<Temp.length();i++)
						{
							System.out.print(Temp.charAt(i));
							if(Temp.charAt(i)==':')
							{
								Num1=i;
								System.out.println("i got this at"+i);
							}
							if(Temp.charAt(i)==';')
							{
								Num2=i;
								System.out.println("i got this at"+i);
								count++;
								if(count==2)
								{
									break;	
								}
							
							}
						}
						String str1=Temp.substring(0, Num1+1);
						
						String str2=Temp.substring(Num2);
						
					//	pane.setStyle("-fx-border-color:orange;-fx-border-width:2;");
						pane.setStyle(str1+"orange"+str2);
						Label l12= (Label) pane.getChildren().get(0);
						String str=l12.getText()+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear());
					//	show_Task.setText(str);
						String tsk="";
						File f = new File(str+".txt");
						try {
							FileReader fr = new FileReader(f);
							 int i;    
					          while((i=fr.read())!=-1)   
					          {
					        	  tsk=tsk+((char)i);  
					          }
					      
							fr.close();
							show_Task.setText(tsk);
				System.out.println("file is successfully readed");
						} catch (IOException e1) {
							
							e1.printStackTrace();
						}
						Add_Task.setVisible(true);
						if(!(Get_paneColour(pane).equals("red")))
						{
							Change_paneColour(pane,"white");
						}
						Label l1= (Label) pane.getChildren().get(0);
						l1.setStyle("-fx-text-fill:black;");
						System.out.println(pane.getStyle());
					}
					
				});
				pane.setOnMouseEntered(new EventHandler<MouseEvent>(){
				
					@Override
					public void handle(MouseEvent arg0) {
							Label l1= (Label) pane.getChildren().get(0);
							l1.setStyle("-fx-text-fill:white;");
						
						
					
						System.out.println(arg0);
						System.out.println(pane.getStyle());
						if(Get_paneColour(pane).equals("white"))
						{
							Change_paneColour(pane,"blue");
						}
					//	System.out.println("hi there my pane col is ->"+Get_paneColour(pane)); 
						
					
					System.out.println(myGrid.getColumnIndex(pane)+" ,"+myGrid.getRowIndex(pane));
						
					}
				});
				pane.setOnMouseExited(new EventHandler<MouseEvent>(){
					
					@Override
					public void handle(MouseEvent arg0) {
						
							Label l1= (Label) pane.getChildren().get(0);
							l1.setStyle("-fx-text-fill:black;");
							String Temp=node.getStyle();
							int Num1 = 0;
							int Num2 = 0;
							System.out.println(Temp);
							for(int i=0;i<Temp.length();i++)
							{
								System.out.print(Temp.charAt(i));
								if(Temp.charAt(i)==':')
								{
									Num1=i;
									//System.out.println("i got this at"+i);
								}
								if(Temp.charAt(i)==';')
								{
									Num2=i;
									break;
								//	System.out.println("i got this at"+i);
								}
							}
							String str1=Temp.substring(0, Num1+1);
							String str2=Temp.substring(Num2);
					 String Temp1=Temp.substring(Num1+1, Num2);
							if(Temp1.equals("blue"))
							{
								node.setStyle(str1+"white"+str2);
							}
					System.out.println(myGrid.getColumnIndex(pane)+" ,"+myGrid.getRowIndex(pane));
						
					}
				});
				
			}
			//first if
		}
		else
		{
			if(node instanceof StackPane)
			{
				StackPane pane =(StackPane)node;
				pane.setOnMouseEntered(new EventHandler<MouseEvent>(){
				
					@Override
					public void handle(MouseEvent arg0) {
						
							Label l1= (Label) pane.getChildren().get(0);
							l1.setStyle("-fx-text-fill:white;");
						node.setStyle("-fx-background-color:red;");
						
					}
				});
				pane.setOnMouseExited(new EventHandler<MouseEvent>(){
					
					@Override
					public void handle(MouseEvent arg0) {
						
							Label l1= (Label) pane.getChildren().get(0);
							l1.setStyle("-fx-text-fill:black;");	
						node.setStyle("-fx-background-color:white;");
					}
				});
				
			}
		}
		i++;
		}
}

public void mybtn (ActionEvent e)
{
	
	
	if(e.getSource().equals(nextbtn))
	{ 
		if(LocalDate.now().minusMonths(b).plusMonths(k).getMonthValue()==12)
		{
			y=y+1;
		
		}
		k=k+1;
	
		theDate.setText(LocalDate.now().toString());
		
		theDate.setText("1"+"/"+Integer.toString(LocalDate.now().minusMonths(b).plusMonths(k).getMonthValue())+"/"+Integer.toString(LocalDate.now().minusYears(ny).plusYears(y).getYear()));
		myGrid.getChildren().clear();
	//	CreateBorder();
		Alarm_Task();
		for(int i =0;i<=6;i++)
		{
			
			 String str=LocalDate.now().getDayOfWeek().of(i+1).toString();
			Label l1 = new Label(str);
			l1.setFont(new Font("Arial",10));
			
			StackPane pane = new StackPane();
			pane.getChildren().add(l1);
		
			myGrid.add(pane, i, 0);
			myGrid.setStyle("-fx-background-color:white;");
		}
		int Start_Ind = 0;
		//what is the length of the month
		
	//	int End_Ind=LocalDate.now().minusYears(ny).plusYears(y).minusMonths(b).plusMonths(k).lengthOfMonth()+1;
		int End_Ind=LocalDate.now().minusMonths(b).plusMonths(k).lengthOfMonth()+1;
		System.out.println(End_Ind);
		boolean flag=false;
		//starting from which day of the week
String Day_first_Name=LocalDate.of(LocalDate.now().minusYears(ny).plusYears(y).getYear(), LocalDate.now().minusYears(ny).plusYears(y).minusMonths(b).plusMonths(k).getMonthValue(), 1).getDayOfWeek().toString();
	for(int j=0;j<=6;j++)
	{
		//nothing special ,just printing out each day of the week
		 String str=LocalDate.now().getDayOfWeek().of(j+1).toString();
		 if(Day_first_Name.equals(str))
		 {
			 Start_Ind=j;
	 }
}
int index=1;
 for(int r=1;r<=6;r++)
 {
	 for(int c=0;c<=6;c++)
	 {
		 if(index==End_Ind)
		 {
			 break;
		 }
		 if(c==Start_Ind)
		 {
			 flag=true;
		 }
		 if(flag==true)
		 {
			 Label l2 = new Label(Integer.toString(index++));
			 l2.setFont(new Font("Arial",20));
			 
			 StackPane pane = new StackPane();
		//	 pane.setStyle("-fx-border-color:grey;");
				pane.getChildren().add(l2);
				pane.setStyle("-fx-background-color:;-fx-border-color:;-fx-border-width:2;");
				Change_paneColour(pane,"white");
				myGrid.add(pane, c, r);
		 }
		
		
	 }
 }

 InitGo();
 Initialize_Filing_Color();
	}
	
	if(e.getSource().equals(prevbtn))
	{
		if(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue()==1)
		{
			y=y-1;
			//b=-2;
		}
		b=b+1;
	
	
		
		theDate.setText("1"+"/"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"/"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear()));
		myGrid.getChildren().clear();
	//	CreateBorder();
		Alarm_Task();
		for(int i =0;i<=6;i++)
		{
			
			 String str=LocalDate.now().getDayOfWeek().of(i+1).toString();
			Label l1 = new Label(str);
			l1.setFont(new Font("Arial",10));
			
		
			
			StackPane pane = new StackPane();
		//	pane.setStyle("-fx-border-color:grey;");
			pane.getChildren().add(l1);
		
			myGrid.add(pane, i, 0);
			myGrid.setStyle("-fx-background-color:white;");
		
		}
		int Start_Ind = 0;
		//what is the length of the month
		
		int End_Ind=LocalDate.now().minusMonths(b).plusMonths(k).lengthOfMonth()+1;
		boolean flag=false;
		//starting from which day of the week
String Day_first_Name=LocalDate.of(LocalDate.now().plusYears(y).minusYears(ny).getYear(), LocalDate.now().plusYears(y).minusYears(ny).plusMonths(k).minusMonths(b).getMonthValue(), 1).getDayOfWeek().toString();
	for(int j=0;j<=6;j++)
	{
		//nothing special ,just printing out each day of the week
		 String str=LocalDate.now().getDayOfWeek().of(j+1).toString();
		 if(Day_first_Name.equals(str))
		 {
			 Start_Ind=j;
	 }
}
int index=1;
 for(int r=1;r<=6;r++)
 {
	 for(int c=0;c<=6;c++)
	 {
		 if(index==End_Ind)
		 {
			 break;
		 }
		 if(c==Start_Ind)
		 {
			 flag=true;
		 }
		 if(flag==true)
		 {
			 Label l2 = new Label(Integer.toString(index++));
			 l2.setFont(new Font("Arial",20));
			 StackPane pane = new StackPane();
				
						pane.getChildren().add(l2);
						pane.setStyle("-fx-background-color:;-fx-border-color:;-fx-border-width:2;");
						Change_paneColour(pane,"white");
						myGrid.add(pane, c, r);
		 }
	 }
 }
 
 InitGo();
 Initialize_Filing_Color();
	}
}
}


